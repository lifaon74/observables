import { IProgress } from '../../../misc/progress/interfaces';
import { ITask} from './interfaces';
import { ITaskContext } from './context/interfaces';
import {
  IFiniteStateObservableExposedOptions,
  TFiniteStateObservableFinalState, TFiniteStateObservableKeyValueMapGeneric, TFiniteStateObservableMode
} from '../finite-state/types';

/** TYPES **/

export type TTaskState =
  'await' // task is awaiting for a 'start'
  | 'run' // task is currently running
  | 'pause' // task execution is paused
  | 'abort' // task is aborted
  | 'complete' // task finished with success
  | 'error' // task errored
  ;

export type TTaskFinalState = TFiniteStateObservableFinalState | 'abort';
export type TTaskMode = TFiniteStateObservableMode;

export interface ITaskKeyValueMap<TValue> extends TFiniteStateObservableKeyValueMapGeneric<TValue, TTaskFinalState> {
  'start': void;
  'pause': void;
  'resume': void;
  'abort': any;

  'progress': IProgress;
}



export type TTaskCreateCallback<TValue> = (this: ITask<TValue>, context: ITaskContext<TValue>) => void;

export interface ITaskOptions extends IFiniteStateObservableExposedOptions<TTaskMode> {
}
