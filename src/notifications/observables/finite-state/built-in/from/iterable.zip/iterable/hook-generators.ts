import { IFiniteStateObservable } from '../../../interfaces';
import { IFromIterableObservableKeyValueMap, TFromIterableObservableFinalState } from './sync/interfaces';
import { IFromAsyncIterableObservableKeyValueMap, TFromAsyncIterableObservableFinalState } from './async/interfaces';
import { TFiniteStateObservableCreateCallback, TFiniteStateObservableMode } from '../../../types';
import { IFiniteStateObservableContext } from '../../../context/interfaces';
import { IsAsyncIterable } from '../../../../../../helpers';

/** TYPES **/

export type TGenerateFiniteStateObservableHookFromIterableWithPauseWorkflowInferValueType<TIterable extends (Iterable<any> | AsyncIterable<any>)> = TIterable extends Iterable<infer TValue>
  ? TValue
  : (
    TIterable extends AsyncIterable<infer TValue>
      ? TValue
      : never
    );

// export type TGetFromIterableObservableFinalState<TIterable extends (Iterable<any> | AsyncIterable<any>)> = TIterable extends Iterable<any>
//   ? TFromIterableObservableFinalState
//   : TFromAsyncIterableObservableFinalState;
//
// export type TGetFiniteStateObservableMode<TIterable extends (Iterable<any> | AsyncIterable<any>)> = TIterable extends Iterable<any>
//   ? TFiniteStateObservableMode
//   : TFiniteStateObservableMode;
//
// export type TGetFromAsyncIterableObservableKeyValueMap<TValue, TIterable extends (Iterable<TValue> | AsyncIterable<TValue>)> = TIterable extends Iterable<TValue>
//   ? IFromIterableObservableKeyValueMap<TValue>
//   : IFromAsyncIterableObservableKeyValueMap<TValue>;

// export type TGenerateFiniteStateObservableHookFromSyncIterableWithPauseWorkflowReturn<TValue> =
//   TFiniteStateObservableCreateCallback<TValue,
//     TFromIterableObservableFinalState,
//     TFiniteStateObservableMode,
//     IFromIterableObservableKeyValueMap<TValue>>;
//
// export type TGenerateFiniteStateObservableHookFromAsyncIterableWithPauseWorkflowReturn<TValue> =
//   TFiniteStateObservableCreateCallback<TValue,
//     TFromIterableObservableFinalState,
//     TFiniteStateObservableMode,
//     IFromIterableObservableKeyValueMap<TValue>>;


export type TGenerateFiniteStateObservableHookFromIterableWithPauseWorkflowReturn<TIterable extends (Iterable<any> | AsyncIterable<any>)> = TIterable extends Iterable<infer TValue>
  ? TFiniteStateObservableCreateCallback<TValue,
    TFromIterableObservableFinalState,
    TFiniteStateObservableMode,
    IFromIterableObservableKeyValueMap<TValue>>
  : TIterable extends AsyncIterable<infer TValue>
    ? TFiniteStateObservableCreateCallback<TValue,
      TFromIterableObservableFinalState,
      TFiniteStateObservableMode,
      IFromIterableObservableKeyValueMap<TValue>>
    : never;

export type TGenerateFiniteStateObservableHookFromIterableWithPauseWorkflowContext<TIterable extends (Iterable<any> | AsyncIterable<any>)> = TIterable extends Iterable<infer TValue>
  ? IFiniteStateObservableContext<TValue, TFromIterableObservableFinalState, TFiniteStateObservableMode, IFromIterableObservableKeyValueMap<TValue>>
  : TIterable extends AsyncIterable<infer TValue>
    ? IFiniteStateObservableContext<TValue, TFromAsyncIterableObservableFinalState, TFiniteStateObservableMode, IFromAsyncIterableObservableKeyValueMap<TValue>>
    : never;

export type TGenerateFiniteStateObservableHookFromIterableWithPauseWorkflowIterator<TIterable extends (Iterable<any> | AsyncIterable<any>)> = TIterable extends Iterable<infer TValue>
  ? Iterator<TValue>
  : TIterable extends AsyncIterable<infer TValue>
    ? AsyncIterator<TValue>
    : never;

export type TGenerateFiniteStateObservableHookFromIterableWithPauseWorkflowResumeFunction<TIterable extends (Iterable<any> | AsyncIterable<any>)> = TIterable extends Iterable<any>
  ? () => void
  : () => Promise<void>;

export type TGenerateFiniteStateObservableHookFromIterableWithPauseWorkflowInstance<TIterable extends (Iterable<any> | AsyncIterable<any>)> = TIterable extends Iterable<infer TValue>
  ? IFiniteStateObservable<TValue, TFromIterableObservableFinalState, TFiniteStateObservableMode, IFromIterableObservableKeyValueMap<TValue>>
  : TIterable extends AsyncIterable<infer TValue>
    ? IFiniteStateObservable<TValue, TFromAsyncIterableObservableFinalState, TFiniteStateObservableMode, IFromAsyncIterableObservableKeyValueMap<TValue>>
    : never;



/** FUNCTION **/

/**
 * Generates an Hook for a FiniteStateObservable, based on an iterable (sync or async):
 *  - when the Observable is freshly observed, creates an iterator from the iterable
 *  - iterates over the elements (emits 'next'). While iterating, if the observable is no more observed pause the iteration
 *  - when all elements are read, emits a 'complete'
 */
export function GenerateFiniteStateObservableHookFromIterableWithPauseWorkflow<TIterable extends (Iterable<any> | AsyncIterable<any>)>(
  iterable: TIterable,
  isAsync: boolean = IsAsyncIterable(iterable),
): TGenerateFiniteStateObservableHookFromIterableWithPauseWorkflowReturn<TIterable> {

  type TValue = TGenerateFiniteStateObservableHookFromIterableWithPauseWorkflowInferValueType<TIterable>;

  return function (context: TGenerateFiniteStateObservableHookFromIterableWithPauseWorkflowContext<TIterable>) {
    let iterator: TGenerateFiniteStateObservableHookFromIterableWithPauseWorkflowIterator<TIterable>;
    let state: 'paused' | 'iterating' | 'complete' = 'paused';

    const pause = (): void => {
      if (state === 'iterating') {
        state = 'paused';
      }
    };

    const generator: () => TGenerateFiniteStateObservableHookFromIterableWithPauseWorkflowIterator<TIterable> = iterable[isAsync ? Symbol.asyncIterator : Symbol.iterator];

    let resume: TGenerateFiniteStateObservableHookFromIterableWithPauseWorkflowResumeFunction<TIterable>;

    if (isAsync) {
      resume = (async () => {
        if (state === 'paused') {
          state = 'iterating';
          let result: IteratorResult<TValue>;
          try {
            while ((state === 'iterating') && !(result = await (iterator as AsyncIterator<TValue>).next()).done) {
              context.next(result.value);
            }
            if (state === 'iterating') {
              context.complete();
            }
          } catch (error) {
            context.error(error);
          }

          if (state === 'iterating') {
            state = 'complete';
          }
        }
      }) as TGenerateFiniteStateObservableHookFromIterableWithPauseWorkflowResumeFunction<TIterable>;
    } else {
      resume = (() => {
        if (state === 'paused') {
          state = 'iterating';
          let result: IteratorResult<TValue>;
          try {
            while ((state === 'iterating') && !(result = (iterator as Iterator<TValue>).next()).done) {
              context.next(result.value);
            }
            if (state === 'iterating') {
              context.complete();
            }
          } catch (error) {
            context.error(error);
          }

          if (state === 'iterating') {
            state = 'complete';
          }
        }
      }) as TGenerateFiniteStateObservableHookFromIterableWithPauseWorkflowResumeFunction<TIterable>;
    }


    return {
      onObserved(): void {
        const instance: TGenerateFiniteStateObservableHookFromIterableWithPauseWorkflowInstance<TIterable> = this as unknown as TGenerateFiniteStateObservableHookFromIterableWithPauseWorkflowInstance<TIterable>;
        if (
          (iterator === void 0)
          && (instance.observers.length === 1) // optional check
          && (instance.state === 'next') // optional check
        ) {
          iterator = generator.call(iterable);
        }

        if (instance.observers.length > 0) { // optional check
          resume();
        }
      },
      onUnobserved(): void {
        const instance: TGenerateFiniteStateObservableHookFromIterableWithPauseWorkflowInstance<TIterable> = this as unknown as TGenerateFiniteStateObservableHookFromIterableWithPauseWorkflowInstance<TIterable>;
        if (
          (!instance.observed)
          && (instance.state === 'next') // optional check
        ) {
          pause();
        }
      },
    };
  } as unknown as TGenerateFiniteStateObservableHookFromIterableWithPauseWorkflowReturn<TIterable>;
}

// /**
//  * Generates an Hook for a FiniteStateObservable, based on an iterable:
//  *  - when the Observable is freshly observed, creates an iterator from the iterable
//  *  - iterates over the elements (emits 'next'). While iterating, if the observable is no more observed pause the iteration
//  *  - when all elements are read, emits a 'complete'
//  */
// export function GenerateFiniteStateObservableHookFromSyncIterableWithPauseWorkflow<TValue>(
//   iterable: Iterable<TValue>
// ): TFiniteStateObservableCreateCallback<TValue, TFromIterableObservableFinalState, TFiniteStateObservableMode, IFromIterableObservableKeyValueMap<TValue>> {
//   type TFinalState = TFromIterableObservableFinalState;
//   type TMode = TFiniteStateObservableMode;
//   type TKVMap = IFromIterableObservableKeyValueMap<TValue>;
//   return function (context: IFiniteStateObservableContext<TValue, TFinalState, TMode, TKVMap>) {
//     let iterator: Iterator<TValue>;
//     let state: 'paused' | 'iterating' | 'complete' = 'paused';
//
//     function pause() {
//       if (state === 'iterating') {
//         state = 'paused';
//       }
//     }
//
//     function resume() {
//       if (state === 'paused') {
//         state = 'iterating';
//         let result: IteratorResult<TValue>;
//         try {
//           while ((state === 'iterating') && !(result = iterator.next()).done) {
//             context.next(result.value);
//           }
//           if (state === 'iterating') {
//             context.complete();
//           }
//         } catch (error) {
//           context.error(error);
//         }
//
//         if (state === 'iterating') {
//           state = 'complete';
//         }
//       }
//     }
//
//     return {
//       onObserved(): void {
//         const instance: IFiniteStateObservable<TValue, TFinalState, TMode, TKVMap> = this as IFiniteStateObservable<TValue, TFinalState, TMode, TKVMap>;
//         if (
//           (iterator === void 0)
//           && (instance.observers.length === 1) // optional check
//           && (instance.state === 'next') // optional check
//         ) {
//           iterator = iterable[Symbol.iterator]();
//         }
//
//         if (instance.observers.length > 0) { // optional check
//           resume();
//         }
//       },
//       onUnobserved(): void {
//         const instance: IFiniteStateObservable<TValue, TFinalState, TMode, TKVMap> = this as IFiniteStateObservable<TValue, TFinalState, TMode, TKVMap>;
//         if (
//           (!instance.observed)
//           && (instance.state === 'next') // optional check
//         ) {
//           pause();
//         }
//       },
//     };
//   };
// }
//
//
// /**
//  * Generates an Hook for a FiniteStateObservable, based on an async iterable:
//  *  - when the Observable is freshly observed, creates an iterator from the iterable
//  *  - iterates over the elements (emits 'next'). While iterating, if the observable is no more observed pause the iteration
//  *  - when all elements are read, emits a 'complete'
//  */
// export function GenerateFiniteStateObservableHookFromAsyncIterableWithPauseWorkflow<TValue>(
//   iterable: AsyncIterable<TValue>
// ): TFiniteStateObservableCreateCallback<TValue, TFromAsyncIterableObservableFinalState, TFiniteStateObservableMode, IFromAsyncIterableObservableKeyValueMap<TValue>> {
//   type TFinalState = TFromAsyncIterableObservableFinalState;
//   type TMode = TFiniteStateObservableMode;
//   type TKVMap = IFromAsyncIterableObservableKeyValueMap<TValue>;
//   return function (context: IFiniteStateObservableContext<TValue, TFinalState, TMode, TKVMap>) {
//     let iterator: AsyncIterator<TValue>;
//     let state: 'paused' | 'iterating' | 'complete' = 'paused';
//
//     function pause() {
//       if (state === 'iterating') {
//         state = 'paused';
//       }
//     }
//
//     async function resume() {
//       if (state === 'paused') {
//         state = 'iterating';
//         let result: IteratorResult<TValue>;
//         try {
//           while ((state === 'iterating') && !(result = await iterator.next()).done) {
//             context.next(result.value);
//           }
//           if (state === 'iterating') {
//             context.complete();
//           }
//         } catch (error) {
//           context.error(error);
//         }
//
//         if (state === 'iterating') {
//           state = 'complete';
//         }
//       }
//     }
//
//     return {
//       onObserved(): void {
//         const instance: IFiniteStateObservable<TValue, TFinalState, TMode, TKVMap> = this as IFiniteStateObservable<TValue, TFinalState, TMode, TKVMap>;
//         if (
//           (iterator === void 0)
//           && (instance.observers.length === 1) // optional check
//           && (instance.state === 'next') // optional check
//         ) {
//           iterator = iterable[Symbol.asyncIterator]();
//         }
//
//         if (instance.observers.length > 0) { // optional check
//           resume(); // cannot fail
//         }
//       },
//       onUnobserved(): void {
//         const instance: IFiniteStateObservable<TValue, TFinalState, TMode, TKVMap> = this as IFiniteStateObservable<TValue, TFinalState, TMode, TKVMap>;
//         if (
//           (!instance.observed)
//           && (instance.state === 'next') // optional check
//         ) {
//           pause();
//         }
//       },
//     };
//   };
// }
//
