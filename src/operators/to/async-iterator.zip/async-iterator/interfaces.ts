import { IAsyncIterator } from '../../../misc/iterable/async-iterator/interfaces';
import { IFiniteStateObservable } from '../../../notifications/observables/finite-state/interfaces';


export interface IAsyncIteratorOfObservableConstructor {
  new<T>(observable: IFiniteStateObservable<T>): IAsyncIteratorOfObservable<T>;
}

export interface IAsyncIteratorOfObservable<T> extends IAsyncIterator<T, void> {

}


