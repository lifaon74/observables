export * from './interfaces';
export { Pipe, IsPipe } from './implementation';
