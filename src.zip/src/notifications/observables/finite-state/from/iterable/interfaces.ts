import {
  IFiniteStateObservableKeyValueMapGeneric, IFiniteStateObservable, IFiniteStateObservableOptions
} from '../../interfaces';
import { KeyValueMapToNotifications } from '../../../../core/notifications-observable/interfaces';

/** TYPES **/

export type IFromIterableObservableKeyValueMap<T> = IFiniteStateObservableKeyValueMapGeneric<T>;
export type TFromIterableObservableNotifications<T> = KeyValueMapToNotifications<IFromIterableObservableKeyValueMap<T>>;

export interface IFromIterableObservableOptions extends IFiniteStateObservableOptions {
}

export type TFromIterableObservableConstructorArgs<T> = [Iterable<T>, IFiniteStateObservableOptions?];


/** INTERFACES **/

export interface IFromIterableObservableConstructor {
  new<T>(iterable: Iterable<T>, options?: IFromIterableObservableOptions): IFromIterableObservable<T>;
}

export interface IFromIterableObservable<T> extends IFiniteStateObservable<T, IFromIterableObservableKeyValueMap<T>> {
}
