import { InitObservableHook, IObservableHookPrivate } from '../../../core/observable/hook';
import {
  IObservable, IObservableConstructor, IObservableContextBase, IObservableHook
} from '../../../core/observable/interfaces';
import {
  INotificationsObservable, INotificationsObservableContext, INotificationsObservableTypedConstructor,
  KeyValueMapToNotifications, KeyValueMapToNotificationsGeneric
} from '../../core/notifications-observable/interfaces';
import {
  FiniteStateKeyValueMapConstraint, IFiniteStateObservable, IFiniteStateObservableConstructor,
  IFiniteStateObservableContext, IFiniteStateObservableContextConstructor,
  IFiniteStateObservableKeyValueMapGeneric, IFiniteStateObservableOptions, IFiniteStateObservableSoftConstructor,
  TFiniteStateObservableConstructorArgs, TFiniteStateObservableFinalState, TFiniteStateObservableMode,
  TFiniteStateObservableState
} from './interfaces';
import { ConstructClassWithPrivateMembers } from '../../../misc/helpers/ClassWithPrivateMembers';
import { AllowObservableContextBaseConstruct, ObservableFactory } from '../../../core/observable/implementation';
import {
  IsNotificationsObservableConstructor, NotificationsObservableContext, NotificationsObservableFactory
} from '../../core/notifications-observable/implementation';
import { Notification } from '../../core/notification/implementation';
import { KeyValueMapKeys, KeyValueMapValues } from '../../core/interfaces';
import { IsObject } from '../../../helpers';
import {
  Constructor, GetSetSuperArgsFunction, HasFactoryWaterMark, IsFactoryClass, MakeFactory
} from '../../../classes/factory';
import { IObserver } from '../../../core/observer/interfaces';
import { ExtractObserverNameAndCallback } from '../../core/notifications-observer/implementation';
import { INotificationsObserverLike } from '../../core/notifications-observer/interfaces';

export const COMPLETE_STATE_OBSERVABLE_PRIVATE = Symbol('finite-state-observable-private');


export interface IFiniteStateObservablePrivate<T, TKVMap extends FiniteStateKeyValueMapConstraint<T, TKVMap>> extends IObservableHookPrivate<KeyValueMapToNotifications<TKVMap>> {
  context: INotificationsObservableContext<TKVMap>;
  values: KeyValueMapToNotifications<TKVMap>[];

  mode: TFiniteStateObservableMode;
  state: TFiniteStateObservableState;
}

export interface IFiniteStateObservableInternal<T, TKVMap extends FiniteStateKeyValueMapConstraint<T, TKVMap>> extends IFiniteStateObservable<T, TKVMap> {
  [COMPLETE_STATE_OBSERVABLE_PRIVATE]: IFiniteStateObservablePrivate<T, TKVMap>;
}


export function ConstructFiniteStateObservable<T, TKVMap extends FiniteStateKeyValueMapConstraint<T, TKVMap>>(
  instance: IFiniteStateObservable<T, TKVMap>,
  context: INotificationsObservableContext<TKVMap>,
  create?: (context: IFiniteStateObservableContext<T, TKVMap>) => (IObservableHook<T> | void),
  options: IFiniteStateObservableOptions = {}
): void {
  ConstructClassWithPrivateMembers(instance, COMPLETE_STATE_OBSERVABLE_PRIVATE);
  const privates: IFiniteStateObservablePrivate<T, TKVMap> = (instance as IFiniteStateObservableInternal<T, TKVMap>)[COMPLETE_STATE_OBSERVABLE_PRIVATE];

  privates.context = context;
  privates.values = [];

  if (IsObject(options)) {
    privates.mode = NormalizeFiniteStateObserversMode(options.mode);
  } else {
    throw new TypeError(`Expected object or void as onCompleteOptions`);
  }

  privates.state = 'next';

  type TObservable = KeyValueMapToNotifications<TKVMap>;

  InitObservableHook<TObservable>(
    instance,
    privates,
    NewFiniteStateObservableContext as unknown as (observable: IObservable<TObservable>) => IObservableContextBase<TObservable>,
    create as unknown as (context: IObservableContextBase<TObservable>) => (IObservableHook<TObservable> | void),
  );
}


export function IsFiniteStateObservable(value: any): value is IFiniteStateObservable<any> {
  return IsObject(value)
    && value.hasOwnProperty(COMPLETE_STATE_OBSERVABLE_PRIVATE as symbol);
}

const IS_COMPLETE_STATE_OBSERVABLE_CONSTRUCTOR = Symbol('is-from-observable-constructor');

export function IsFiniteStateObservableConstructor(value: any): boolean {
  return (typeof value === 'function') && ((value === FiniteStateObservable) || HasFactoryWaterMark(value, IS_COMPLETE_STATE_OBSERVABLE_CONSTRUCTOR));
}


export function NormalizeFiniteStateObserversMode(mode?: TFiniteStateObservableMode): TFiniteStateObservableMode {
  switch (mode) {
    case void 0:
      return 'once';
    case 'once':
    case 'uniq':
    case 'cache':
    case 'cache-final-state':
    case 'cache-all':
      return mode;
    default:
      throw new TypeError(`Expected 'once', 'uniq', 'cache', 'cache-final-state' or 'cache-all' as mode`);
  }
}

export function IsFiniteStateObservableFinalNotificationName(name: string): boolean {
  return (
    (name === 'complete')
    || (name === 'error')
  );
}

export function IsFiniteStateObservableNotificationName(name: string): boolean {
  return (name === 'next')
    || IsFiniteStateObservableFinalNotificationName(name);
}


export function IsFiniteStateObservableCachingValues<T, TKVMap extends FiniteStateKeyValueMapConstraint<T, TKVMap>>(instance: IFiniteStateObservable<T, TKVMap>): boolean {
  return IsFiniteStateObservableCachingValuesMode((instance as IFiniteStateObservableInternal<T, TKVMap>)[COMPLETE_STATE_OBSERVABLE_PRIVATE].mode);
}

export function IsFiniteStateObservableCachingValuesMode(mode: TFiniteStateObservableMode): boolean {
  return (
    (mode === 'cache')
    || (mode === 'cache-final-state')
    || (mode === 'cache-all')
  );
}

// export function FiniteStateObservableReset<T, TKVMap extends FiniteStateKeyValueMapConstraint<T, TKVMap>>(instance: IFiniteStateObservable<T, TKVMap>): void {
//   (instance as IFiniteStateObservableInternal<T, TKVMap>)[COMPLETE_STATE_OBSERVABLE_PRIVATE].state = 'next';
//   (instance as IFiniteStateObservableInternal<T, TKVMap>)[COMPLETE_STATE_OBSERVABLE_PRIVATE].values = [];
// }

export function ThrowFiniteStateObservableCannotEmitAfterFiniteState(state: TFiniteStateObservableState, notificationName: string): never {
  throw new TypeError(`Cannot emit a notification with the name '${ notificationName }' when the observable is in '${ state }' state`);
}

/**
 * Called when this Observable emits a data
 * @param instance
 * @param notification
 */
export function FiniteStateObservableOnEmit<T, TKVMap extends FiniteStateKeyValueMapConstraint<T, TKVMap>>(instance: IFiniteStateObservable<T, TKVMap>, notification: KeyValueMapToNotifications<TKVMap>): void {
  const privates: IFiniteStateObservablePrivate<T, TKVMap> = (instance as IFiniteStateObservableInternal<T, TKVMap>)[COMPLETE_STATE_OBSERVABLE_PRIVATE];
  const isFiniteState = IsFiniteStateObservableFinalNotificationName(notification.name);

  if (isFiniteState || (notification.name === 'next')) {
    if (privates.state === 'next') {
      if (
        (privates.mode === 'cache')
        || (privates.mode === 'cache-all')
        || (
          (privates.mode === 'cache-final-state')
          && isFiniteState
        )
      ) {
        privates.values.push(notification);
      }

      if (isFiniteState) {
        privates.state = notification.name as TFiniteStateObservableFinalState;
      }
    } else {
      ThrowFiniteStateObservableCannotEmitAfterFiniteState(privates.state, notification.name);
    }
  // } else if (notification.name === 'reset') {
  //   privates.state = 'next';
  //   privates.values = [];
  } else {
    if (privates.mode === 'cache-all') {
      privates.values.push(notification);
    }
  }
}

export function FiniteStateObservableReset<T, TKVMap extends FiniteStateKeyValueMapConstraint<T, TKVMap>>(instance: IFiniteStateObservable<T, TKVMap>): void {
  if (instance.observed) {
    throw new Error(`The FiniteStateObservable may only reset when not observed`);
  } else {
    const privates: IFiniteStateObservablePrivate<T, TKVMap> = (instance as IFiniteStateObservableInternal<T, TKVMap>)[COMPLETE_STATE_OBSERVABLE_PRIVATE];
    privates.state = 'next';
    privates.values = [];
  }
}


export function FiniteStateObservableOnObserved<T, TKVMap extends FiniteStateKeyValueMapConstraint<T, TKVMap>>(instance: IFiniteStateObservable<T, TKVMap>, observer: IObserver<KeyValueMapToNotifications<TKVMap>>): void {
  const privates: IFiniteStateObservablePrivate<T, TKVMap> = (instance as IFiniteStateObservableInternal<T, TKVMap>)[COMPLETE_STATE_OBSERVABLE_PRIVATE];
  if (
    (privates.mode === 'uniq')
    && (privates.state !== 'next')
  ) {
    const result: INotificationsObserverLike<string, any> | null = ExtractObserverNameAndCallback<string, any>(observer);
    if (
      (result !== null)
      && (
        (result.name === 'next')
        || (result.name === 'complete')
        || (result.name === 'error')
      )
    ) {
      throw new Error(`Cannot observe this Observable because it is the state '${ privates.state }'.`);
    }
  }

  // INFO privates.values is empty if not cached
  for (let i = 0, l = privates.values.length; i < l; i++) {
    observer.emit(privates.values[i]);
  }

  privates.onObserveHook(observer);
}

export function FiniteStateObservableOnUnobserved<T, TKVMap extends FiniteStateKeyValueMapConstraint<T, TKVMap>>(instance: IFiniteStateObservable<T, TKVMap>, observer: IObserver<KeyValueMapToNotifications<TKVMap>>): void {
  (instance as IFiniteStateObservableInternal<T, TKVMap>)[COMPLETE_STATE_OBSERVABLE_PRIVATE].onUnobserveHook(observer);
}

export function FiniteStateObservableGetState<T, TKVMap extends FiniteStateKeyValueMapConstraint<T, TKVMap>>(instance: IFiniteStateObservable<T, TKVMap>): TFiniteStateObservableState {
  return (instance as IFiniteStateObservableInternal<T, TKVMap>)[COMPLETE_STATE_OBSERVABLE_PRIVATE].state;
}

export function FiniteStateObservableGetMode<T, TKVMap extends FiniteStateKeyValueMapConstraint<T, TKVMap>>(instance: IFiniteStateObservable<T, TKVMap>): TFiniteStateObservableMode {
  return (instance as IFiniteStateObservableInternal<T, TKVMap>)[COMPLETE_STATE_OBSERVABLE_PRIVATE].mode;
}


function PureFiniteStateObservableFactory<TBase extends Constructor<INotificationsObservable<IFiniteStateObservableKeyValueMapGeneric<any>>>>(superClass: TBase) {
  type T = any;
  type TKVMap = IFiniteStateObservableKeyValueMapGeneric<T>;

  if (!IsNotificationsObservableConstructor(superClass)) {
    throw new TypeError(`Expected NotificationsObservable constructor as superClass`);
  }
  const setSuperArgs = GetSetSuperArgsFunction(IsFactoryClass(superClass));

  return class FiniteStateObservable extends superClass implements IFiniteStateObservable<T, TKVMap> {
    constructor(...args: any[]) {
      const [create, options]: TFiniteStateObservableConstructorArgs<T, TKVMap> = args[0];
      let context: INotificationsObservableContext<TKVMap>;
      super(...setSuperArgs(args.slice(1), [
        (_context: INotificationsObservableContext<TKVMap>) => {
          context = _context;
          return {
            onObserved: (observer: IObserver<KeyValueMapToNotifications<TKVMap>>): void => {
              FiniteStateObservableOnObserved(this, observer);
            },
            onUnobserved: (observer: IObserver<KeyValueMapToNotifications<TKVMap>>): void => {
              FiniteStateObservableOnUnobserved(this, observer);
            },
          };
        }
      ]));
      // @ts-ignore
      ConstructFiniteStateObservable<T, TKVMap>(this, context, create, options);
    }

    get state(): TFiniteStateObservableState {
      return FiniteStateObservableGetState<T, TKVMap>(this);
    }

    get mode(): TFiniteStateObservableMode {
      return FiniteStateObservableGetMode<T, TKVMap>(this);
    }
  };
}

export let FiniteStateObservable: IFiniteStateObservableConstructor;

export function FiniteStateObservableFactory<TBase extends Constructor<INotificationsObservable<IFiniteStateObservableKeyValueMapGeneric<any>>>>(superClass: TBase) {
  return MakeFactory<IFiniteStateObservableConstructor, [], TBase>(PureFiniteStateObservableFactory, [], superClass, {
    name: 'FiniteStateObservable',
    instanceOf: FiniteStateObservable,
    waterMarks: [IS_COMPLETE_STATE_OBSERVABLE_CONSTRUCTOR],
  });
}

export function FiniteStateObservableBaseFactory<TBase extends Constructor>(superClass: TBase) { // INotificationsObservableTypedConstructor<FiniteStateObservableKeyValueMapGeneric<any>>
  return MakeFactory<IFiniteStateObservableSoftConstructor, [
    INotificationsObservableTypedConstructor<IFiniteStateObservableKeyValueMapGeneric<any>>,
    IObservableConstructor
    ], TBase>(PureFiniteStateObservableFactory, [NotificationsObservableFactory, ObservableFactory], superClass, {
    name: 'FiniteStateObservable',
    instanceOf: FiniteStateObservable,
    waterMarks: [IS_COMPLETE_STATE_OBSERVABLE_CONSTRUCTOR],
  });
}


FiniteStateObservable = class FiniteStateObservable1 extends FiniteStateObservableBaseFactory<ObjectConstructor>(Object) {
  constructor(create?: (context: IFiniteStateObservableContext<any, IFiniteStateObservableKeyValueMapGeneric<any>>) => (IObservableHook<any> | void), options?: IFiniteStateObservableOptions) {
    super([create as any, options], [], []);
  }
} as IFiniteStateObservableConstructor;


/*--------------------------*/


export function NewFiniteStateObservableContext<T, TKVMap extends FiniteStateKeyValueMapConstraint<T, TKVMap>>(observable: IFiniteStateObservable<T, TKVMap>): IFiniteStateObservableContext<T, TKVMap> {
  AllowObservableContextBaseConstruct(true);
  const context: IFiniteStateObservableContext<T, TKVMap> = new ((FiniteStateObservableContext as any) as IFiniteStateObservableContextConstructor)<T, TKVMap>(observable);
  AllowObservableContextBaseConstruct(false);
  return context;
}


export class FiniteStateObservableContext<T, TKVMap extends FiniteStateKeyValueMapConstraint<T, TKVMap> = IFiniteStateObservableKeyValueMapGeneric<T>> extends NotificationsObservableContext<TKVMap> implements IFiniteStateObservableContext<T, TKVMap> {
  protected constructor(observable: IFiniteStateObservable<T, TKVMap>) {
    super(observable);
  }

  get observable(): IFiniteStateObservable<T, TKVMap> {
    return super.observable as IFiniteStateObservable<T, TKVMap>;
  }

  emit(value: KeyValueMapToNotifications<TKVMap>): void {
    FiniteStateObservableOnEmit<T, TKVMap>(this.observable, value);
    super.emit(value);
  }

  dispatch<K extends KeyValueMapKeys<TKVMap>>(name: K, value: TKVMap[K]): void {
    this.emit(new Notification<K, TKVMap[K]>(name, value) as KeyValueMapToNotificationsGeneric<TKVMap> as KeyValueMapToNotifications<TKVMap>);
  }

  next(value: T): void {
    this.dispatch('next' as KeyValueMapKeys<TKVMap>, value as KeyValueMapValues<TKVMap>);
  }

  complete(): void {
    this.dispatch('complete' as KeyValueMapKeys<TKVMap>, void 0 as KeyValueMapValues<TKVMap>);
  }

  error(error?: any): void {
    this.dispatch('error' as KeyValueMapKeys<TKVMap>, error as KeyValueMapValues<TKVMap>);
  }

  reset(): void {
    // this.dispatch('reset' as KeyValueMapKeys<TKVMap>, void 0 as KeyValueMapValues<TKVMap>);
    FiniteStateObservableReset<T, TKVMap>(this.observable);
  }
}

