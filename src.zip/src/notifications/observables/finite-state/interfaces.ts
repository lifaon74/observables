import { KeyValueMapConstraint } from '../../core/interfaces';
import {
  INotificationsObservable, INotificationsObservableContext, KeyValueMapToNotifications, TNotificationsObservableHook
} from '../../core/notifications-observable/interfaces';

/**
 * What to do when the FiniteStateObservable emits a value:
 *  INFO: except for 'cache-all', the FiniteStateObservable doesn't care of notifications different than 'next', 'complete' or 'error'
 */
export type TFiniteStateObservableMode =
  'once' // (default) does not cache any values => after the final state ('complete' or 'error'), no observers will ever receive a value ('next')
  | 'uniq' // does not cache any values => after the final state, throws an error if a new observer observes 'next', 'complete' or 'error'.
  | 'cache' // caches own notifications ('next', 'complete' and 'error'). Every observer will receive the whole list of own emitted notifications
  | 'cache-final-state' // caches 'complete' or 'error' notification. Every observer will receive this final state notification
  | 'cache-all' // caches all notifications (including ones with a different name than 'next', 'complete' and 'error'). Every observer will receive the whole list of all emitted notifications
  ;

export type TFiniteStateObservableFinalState =
  | 'complete' // context.complete() called, cannot emit anymore data
  | 'error' // context.error(err) called, cannot emit anymore data
  ;

export type TFiniteStateObservableState =
  'next' // may emit data though 'next'
  | TFiniteStateObservableFinalState
  ;


export interface IFiniteStateObservableOptions {
  mode?: TFiniteStateObservableMode; // default: 'once'
}

export type IFiniteStateObservableKeyValueMapGeneric<T> = {
  'next': T; // incoming values
  'complete': void; // when the Observable has no more data to emit
  'error': any; // when the Observable errored
  'reset': void; // when the Observable resets => this means than previously received notifications should be discarded
};


export type FiniteStateKeyValueMapConstraint<T, TKVMap extends object> = KeyValueMapConstraint<TKVMap, IFiniteStateObservableKeyValueMapGeneric<T>>;

// what should emit an Observable with a similar behaviour of a FiniteStateObservable
export type TFiniteStateObservableLikeNotifications<T> = KeyValueMapToNotifications<IFiniteStateObservableKeyValueMapGeneric<T>>;

export interface IFiniteStateObservableHook<T, TKVMap extends FiniteStateKeyValueMapConstraint<T, TKVMap>> extends TNotificationsObservableHook<TKVMap> {
}


export type TFiniteStateObservableCreateCallback<T, TKVMap extends FiniteStateKeyValueMapConstraint<T, TKVMap>> = ((context: IFiniteStateObservableContext<T, TKVMap>) => (IFiniteStateObservableHook<T, TKVMap> | void));

export type TFiniteStateObservableConstructorArgs<T, TKVMap extends FiniteStateKeyValueMapConstraint<T, TKVMap>> =
  [TFiniteStateObservableCreateCallback<T, TKVMap>?, IFiniteStateObservableOptions?];


export interface IFiniteStateObservableConstructor {
  new<T, TKVMap extends FiniteStateKeyValueMapConstraint<T, TKVMap> = IFiniteStateObservableKeyValueMapGeneric<T>>(
    create?: TFiniteStateObservableCreateCallback<T, TKVMap>,
    options?: IFiniteStateObservableOptions,
  ): IFiniteStateObservable<T, TKVMap>;
}

export interface IFiniteStateObservableSoftConstructor {
  new<T>(
    create?: (context: IFiniteStateObservableKeyValueMapGeneric<T>) => (IFiniteStateObservableHook<T, IFiniteStateObservableKeyValueMapGeneric<T>> | void),
    options?: IFiniteStateObservableOptions,
  ): IFiniteStateObservable<T, IFiniteStateObservableKeyValueMapGeneric<T>>;
}

export interface IFiniteStateObservableTypedConstructor<T, TKVMap extends FiniteStateKeyValueMapConstraint<T, TKVMap>> {
  new(
    create?: TFiniteStateObservableCreateCallback<T, TKVMap>,
    options?: IFiniteStateObservableOptions,
  ): IFiniteStateObservable<T, TKVMap>;
}

// const a: ConstructorParameters<IFiniteStateObservableConstructor>;
// const b: ConstructorParameters<IFiniteStateObservableSoftConstructor>;

/**
 * A FiniteStateObservable represents an Observable with a final state (complete or errored).
 * This may be useful for streams with a non infinite list of values like iterables, promises, RXJS's Observables, etc...
 */
export interface IFiniteStateObservable<T, TKVMap extends FiniteStateKeyValueMapConstraint<T, TKVMap> = IFiniteStateObservableKeyValueMapGeneric<T>> extends INotificationsObservable<TKVMap> {
  readonly state: TFiniteStateObservableState;
  readonly mode: TFiniteStateObservableMode;
}


/*---------------------------*/

export interface IFiniteStateObservableContextConstructor {
  new<T, TKVMap extends FiniteStateKeyValueMapConstraint<T, TKVMap>>(observable: IFiniteStateObservable<T, TKVMap>): IFiniteStateObservableContext<T, TKVMap>;
}

export interface IFiniteStateObservableContext<T, TKVMap extends FiniteStateKeyValueMapConstraint<T, TKVMap> = IFiniteStateObservableKeyValueMapGeneric<T>> extends INotificationsObservableContext<TKVMap> {
  readonly observable: IFiniteStateObservable<T, TKVMap>;

  next(value: T): void; // emits Notification('next', value)
  complete(): void; // emits Notification('complete', void 0)
  error(error?: any): void; // emits Notification('error', error)

  /**
   * clears the cache, resets the state to 'next' and emits a Notification('reset', void 0)
   * Should be called only when this Observables is not observed
   */
  reset(): void;
}


