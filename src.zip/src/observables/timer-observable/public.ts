export * from './interfaces';
export { TimerObservable, IsTimerObservable } from './implementation';
