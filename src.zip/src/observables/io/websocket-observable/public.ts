export * from './interfaces';
export { WebSocketIO, IsWebSocketIO } from './implementation';
