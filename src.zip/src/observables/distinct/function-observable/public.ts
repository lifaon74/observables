export * from './interfaces';
export { FunctionObservable, IsFunctionObservable } from './implementation';
