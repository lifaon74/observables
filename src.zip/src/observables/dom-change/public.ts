export * from './interfaces';
export { DOMChangeObservable, IsDOMChangeObservable } from './implementation';
