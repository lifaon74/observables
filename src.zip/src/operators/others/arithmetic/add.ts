// import { IObservable } from '../../core/observable/interfaces';
// import { ArithmeticAddObservable } from '../../observables/arithmetic/implementation';
// import { IArithmeticAddObservable } from '../../observables/arithmetic/interfaces';
//
// export function and(...observables: IObservable<number>[]): IArithmeticAddObservable {
//   return new ArithmeticAddObservable(observables);
// }