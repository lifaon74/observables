export * from './interfaces';
export { ReadonlyTuple, IsReadonlyTuple, ReadonlyList, IsReadonlyList } from './implementation';
