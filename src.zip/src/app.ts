import { test } from './tests/test';

window.onload = () => {
  test();
};






